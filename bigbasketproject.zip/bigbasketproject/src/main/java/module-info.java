module bigbasketproject {
	exports bigbasket.BigBasket;
	exports bigbasket.BigBasket.resources;
	exports bigbasket.BigBasket.pageObjects;

	requires extentreports;
	requires org.apache.commons.io;
	requires org.apache.logging.log4j;
	requires org.openqa.selenium.chrome;
	requires org.openqa.selenium.core;
	requires org.openqa.selenium.firefox;
	requires org.openqa.selenium.ie;
	requires org.openqa.selenium.remote;
}